var searchData=
[
  ['s_5fquote',['S_QUOTE',['../classArffLexer.html#a7c9b521442e7437f35afa1ffe5abe5ec',1,'ArffLexer']]],
  ['space',['SPACE',['../classArffLexer.html#aef3b90da3443fe005cf94799b3e4798b',1,'ArffLexer']]]
];
