var searchData=
[
  ['float',['FLOAT',['../arff__value_8h.html#a618674cfaa41c32291efe6766a7c9116a9cf4a0866224b0bb4a7a895da27c9c4c',1,'arff_value.h']]]
];
