var searchData=
[
  ['icompare',['icompare',['../arff__utils_8cpp.html#ad950f786e9bd90023a4c6b7ccde1d541',1,'icompare(const std::string &amp;str, const std::string &amp;ref):&#160;arff_utils.cpp'],['../arff__utils_8h.html#ad950f786e9bd90023a4c6b7ccde1d541',1,'icompare(const std::string &amp;str, const std::string &amp;ref):&#160;arff_utils.cpp']]],
  ['is_5fnewline',['is_newline',['../classArffScanner.html#a7e4c37bb5ce3ad8428e4d195b321ad40',1,'ArffScanner']]]
];
