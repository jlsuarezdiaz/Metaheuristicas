var searchData=
[
  ['int32',['int32',['../arff__utils_8h.html#a5eb512da689eec1a7472ab97e2ab6be3',1,'arff_utils.h']]],
  ['int64',['int64',['../arff__utils_8h.html#aecfc3c54bd29ad5964e1c1c3ccbf89df',1,'arff_utils.h']]]
];
