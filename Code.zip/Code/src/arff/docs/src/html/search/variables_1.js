var searchData=
[
  ['comma',['COMMA',['../classArffLexer.html#a90dbb00d14ae9312d42edd6ea053e1e3',1,'ArffLexer']]],
  ['comment',['COMMENT',['../classArffLexer.html#a1e9b5d9d5c132109d628fcd6fac24c2b',1,'ArffLexer']]]
];
