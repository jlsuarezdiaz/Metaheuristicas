var searchData=
[
  ['b_5fclose',['B_CLOSE',['../classArffLexer.html#ade4c887034492b730693cf8cb7d868c6',1,'ArffLexer']]],
  ['b_5fopen',['B_OPEN',['../classArffLexer.html#a2659fdbd7e37658d3be9b8da2565e982',1,'ArffLexer']]]
];
