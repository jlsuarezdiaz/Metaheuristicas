var searchData=
[
  ['end_5fof_5ffile',['END_OF_FILE',['../arff__token_8h.html#ab2897012e129352ac3f7f491ff1a9676a7ea291c26de584b23fd7f9111784f860',1,'arff_token.h']]]
];
