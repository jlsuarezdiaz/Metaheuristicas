var searchData=
[
  ['icompare',['icompare',['../arff__utils_8cpp.html#ad950f786e9bd90023a4c6b7ccde1d541',1,'icompare(const std::string &amp;str, const std::string &amp;ref):&#160;arff_utils.cpp'],['../arff__utils_8h.html#ad950f786e9bd90023a4c6b7ccde1d541',1,'icompare(const std::string &amp;str, const std::string &amp;ref):&#160;arff_utils.cpp']]],
  ['int32',['int32',['../arff__utils_8h.html#a5eb512da689eec1a7472ab97e2ab6be3',1,'arff_utils.h']]],
  ['int64',['int64',['../arff__utils_8h.html#aecfc3c54bd29ad5964e1c1c3ccbf89df',1,'arff_utils.h']]],
  ['integer',['INTEGER',['../arff__value_8h.html#a618674cfaa41c32291efe6766a7c9116a5a063e265d2ac903b6808e9f6e73ec46',1,'arff_value.h']]],
  ['is_5fnewline',['is_newline',['../classArffScanner.html#a7e4c37bb5ce3ad8428e4d195b321ad40',1,'ArffScanner']]]
];
