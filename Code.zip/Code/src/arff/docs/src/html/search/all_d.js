var searchData=
[
  ['parse',['parse',['../classArffParser.html#aea4e1f2ba113816d788617998b1c35ce',1,'ArffParser']]],
  ['previous',['previous',['../classArffScanner.html#a06c5d778a14d10f6af0f73c896a6bfb0',1,'ArffScanner']]]
];
