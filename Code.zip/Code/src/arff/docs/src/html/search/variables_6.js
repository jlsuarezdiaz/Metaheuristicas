var searchData=
[
  ['tab',['TAB',['../classArffLexer.html#a67ea1ea10b79c0069e34935f4e66eac3',1,'ArffLexer']]]
];
