var searchData=
[
  ['arffdateformat',['ArffDateFormat',['../arff__data_8h.html#a730c1f2e96f25e3a7b6fe0e172684116',1,'arff_data.h']]],
  ['arffnominal',['ArffNominal',['../arff__data_8h.html#a6fa12392b38c81beed04483919bebe24',1,'arff_data.h']]]
];
