var searchData=
[
  ['column',['column',['../classArffScanner.html#afd634ac0423919ca2c281a886e5d9327',1,'ArffScanner']]],
  ['comma',['COMMA',['../classArffLexer.html#a90dbb00d14ae9312d42edd6ea053e1e3',1,'ArffLexer']]],
  ['comment',['COMMENT',['../classArffLexer.html#a1e9b5d9d5c132109d628fcd6fac24c2b',1,'ArffLexer']]],
  ['current',['current',['../classArffScanner.html#ac24dec6755420cdc9a91728a475b1a9b',1,'ArffScanner']]]
];
