var searchData=
[
  ['add',['add',['../classArffInstance.html#a3b6b0ce99f24bff0be038b3fd7b48730',1,'ArffInstance']]],
  ['add_5fattr',['add_attr',['../classArffData.html#a4807069ca506154e83f530b8a755e496',1,'ArffData']]],
  ['add_5fdate_5fformat',['add_date_format',['../classArffData.html#a827dba98c1aa15c389f3a57654032099',1,'ArffData']]],
  ['add_5finstance',['add_instance',['../classArffData.html#ac2770bee22b01592779c2e86c9653db3',1,'ArffData']]],
  ['add_5fnominal_5fval',['add_nominal_val',['../classArffData.html#aac8df3210ba4c444cba3727b1bd3b206',1,'ArffData']]],
  ['arff_5ftoken2str',['arff_token2str',['../arff__token_8cpp.html#a91fc447ab8e312561730c9a55ecb8f05',1,'arff_token2str(ArffTokenEnum type):&#160;arff_token.cpp'],['../arff__token_8h.html#a91fc447ab8e312561730c9a55ecb8f05',1,'arff_token2str(ArffTokenEnum type):&#160;arff_token.cpp']]],
  ['arff_5fvalue2str',['arff_value2str',['../arff__value_8cpp.html#a1981ad12f3d225d29fceb0ade6129224',1,'arff_value2str(ArffValueEnum e):&#160;arff_value.cpp'],['../arff__value_8h.html#a1981ad12f3d225d29fceb0ade6129224',1,'arff_value2str(ArffValueEnum e):&#160;arff_value.cpp']]],
  ['arffattr',['ArffAttr',['../classArffAttr.html#aa95fce4dccf5be52f4cefa4081adde2f',1,'ArffAttr']]],
  ['arffdata',['ArffData',['../classArffData.html#ab999843ea3177c41ae1d06381a5842f1',1,'ArffData']]],
  ['arffinstance',['ArffInstance',['../classArffInstance.html#ae94d4b9c95c92b11e73098b314bac19a',1,'ArffInstance']]],
  ['arfflexer',['ArffLexer',['../classArffLexer.html#a331dd46bcec80ee95873dc35f794c899',1,'ArffLexer']]],
  ['arffparser',['ArffParser',['../classArffParser.html#ac3227bf6bdbbb4bffbd6e34e7607f2a1',1,'ArffParser']]],
  ['arffscanner',['ArffScanner',['../classArffScanner.html#ab9f488de67824d42c2ad801f08988ecd',1,'ArffScanner']]],
  ['arfftoken',['ArffToken',['../structArffToken.html#ad99bffbd9d7ac488ea4c5ac40588d32e',1,'ArffToken::ArffToken(const std::string &amp;_str, ArffTokenEnum _token)'],['../structArffToken.html#a0ea1ca1ff9c76fcf72a37e6946f840c5',1,'ArffToken::ArffToken(const ArffToken &amp;_src)']]],
  ['arffvalue',['ArffValue',['../classArffValue.html#af854307b640f4baee13e1a24b7e569d1',1,'ArffValue::ArffValue(int32 i=0)'],['../classArffValue.html#a18d068adb3e255be946d86b4ae309579',1,'ArffValue::ArffValue(float f)'],['../classArffValue.html#ae2b232b572ecb05a022e22f1e16ca90d',1,'ArffValue::ArffValue(const std::string &amp;str, bool convert=true, bool is_date=false)'],['../classArffValue.html#ab593fb2f143d5852ce8d99b86eb6a4a1',1,'ArffValue::ArffValue(const ArffValue &amp;src)'],['../classArffValue.html#a310fc75b473e5cdef2cd2d325272d8df',1,'ArffValue::ArffValue(ArffValueEnum type)']]]
];
