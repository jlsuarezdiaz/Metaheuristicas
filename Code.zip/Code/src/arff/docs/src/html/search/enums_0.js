var searchData=
[
  ['arfftokenenum',['ArffTokenEnum',['../arff__token_8h.html#ab2897012e129352ac3f7f491ff1a9676',1,'arff_token.h']]],
  ['arffvalueenum',['ArffValueEnum',['../arff__value_8h.html#a618674cfaa41c32291efe6766a7c9116',1,'arff_value.h']]]
];
