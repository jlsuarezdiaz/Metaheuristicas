var searchData=
[
  ['unknown_5ftoken',['UNKNOWN_TOKEN',['../arff__token_8h.html#ab2897012e129352ac3f7f491ff1a9676af6de97fa9fec031dd6e43b7ae1d66265',1,'arff_token.h']]],
  ['unknown_5fval',['UNKNOWN_VAL',['../arff__value_8h.html#a618674cfaa41c32291efe6766a7c9116abfe90ce3d05a6303c74dbe559feb19e5',1,'arff_value.h']]]
];
