var searchData=
[
  ['column',['column',['../classArffScanner.html#afd634ac0423919ca2c281a886e5d9327',1,'ArffScanner']]],
  ['current',['current',['../classArffScanner.html#ac24dec6755420cdc9a91728a475b1a9b',1,'ArffScanner']]]
];
