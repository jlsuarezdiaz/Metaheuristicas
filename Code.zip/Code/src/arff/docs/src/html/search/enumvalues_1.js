var searchData=
[
  ['brkt_5fclose',['BRKT_CLOSE',['../arff__token_8h.html#ab2897012e129352ac3f7f491ff1a9676aa4e9f404fd5709f942dd826ccb81d1af',1,'arff_token.h']]],
  ['brkt_5fopen',['BRKT_OPEN',['../arff__token_8h.html#ab2897012e129352ac3f7f491ff1a9676a144b86c004d1816f6e2ef715bab78408',1,'arff_token.h']]]
];
