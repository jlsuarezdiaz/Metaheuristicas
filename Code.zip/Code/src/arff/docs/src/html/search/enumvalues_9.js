var searchData=
[
  ['string',['STRING',['../arff__value_8h.html#a618674cfaa41c32291efe6766a7c9116aee847e634a4297b274316de8a8ca9921',1,'arff_value.h']]],
  ['string_5ftoken',['STRING_TOKEN',['../arff__token_8h.html#ab2897012e129352ac3f7f491ff1a9676a67fc1734265f2e84177a9bc259f1b187',1,'arff_token.h']]]
];
