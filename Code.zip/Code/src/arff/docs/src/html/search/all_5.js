var searchData=
[
  ['end_5fof_5ffile',['END_OF_FILE',['../arff__token_8h.html#ab2897012e129352ac3f7f491ff1a9676a7ea291c26de584b23fd7f9111784f860',1,'arff_token.h']]],
  ['eof',['eof',['../classArffScanner.html#a48b2314a15fc1bd5aa94bc2c204bfa21',1,'ArffScanner']]],
  ['err_5fmsg',['err_msg',['../classArffScanner.html#a32da8fa47de4a02295857b6b830b1f05',1,'ArffScanner']]]
];
