var searchData=
[
  ['get',['get',['../classArffInstance.html#a924c707443fb93070e8c52bf078b16a3',1,'ArffInstance']]],
  ['get_5fattr',['get_attr',['../classArffData.html#a8acde7abe71920193c3968e5f2adab89',1,'ArffData']]],
  ['get_5fdate_5fformat',['get_date_format',['../classArffData.html#a650aa21cbd930057e4621d2d0a7c0252',1,'ArffData']]],
  ['get_5finstance',['get_instance',['../classArffData.html#a16ea96c2c0f61b29af713489d0ada49e',1,'ArffData']]],
  ['get_5fnominal',['get_nominal',['../classArffData.html#a921479a609dfcd2c2d6a6d2284c08300',1,'ArffData']]],
  ['get_5frelation_5fname',['get_relation_name',['../classArffData.html#aec52700c3f866d06805b51d6903c565d',1,'ArffData']]]
];
