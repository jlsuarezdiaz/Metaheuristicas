var searchData=
[
  ['newline',['NEWLINE',['../classArffScanner.html#a0a92b7c31c391d09a53bc48e2f80ab62',1,'ArffScanner']]]
];
