var searchData=
[
  ['name',['name',['../classArffAttr.html#ae47b86af21764e254a1f6528c6c8b5cc',1,'ArffAttr']]],
  ['newline',['NEWLINE',['../classArffScanner.html#a0a92b7c31c391d09a53bc48e2f80ab62',1,'ArffScanner']]],
  ['next',['next',['../classArffScanner.html#a50b139a0ba07e0a9ddb372ab2496c93c',1,'ArffScanner']]],
  ['next_5ftoken',['next_token',['../classArffLexer.html#a3d6d15551879d6e841b14c229377aa84',1,'ArffLexer']]],
  ['nominal',['NOMINAL',['../arff__value_8h.html#a618674cfaa41c32291efe6766a7c9116ae2bd7b57b3f0bb02e66e42dbacc5c7fc',1,'arff_value.h']]],
  ['num2str',['num2str',['../arff__utils_8h.html#ab8ddab11ec003ee84752b9c1ed1cdbab',1,'arff_utils.h']]],
  ['num_5fattributes',['num_attributes',['../classArffData.html#aeb6cbea0c41843eb34d2de5b73ca759c',1,'ArffData']]],
  ['num_5finstances',['num_instances',['../classArffData.html#a5d41f571d1782afc17d0db40fa02d561',1,'ArffData']]],
  ['numeric',['NUMERIC',['../arff__value_8h.html#a618674cfaa41c32291efe6766a7c9116a8036f3be5700d4eb67d27fab554d5e0c',1,'arff_value.h']]],
  ['numeric_5ftoken',['NUMERIC_TOKEN',['../arff__token_8h.html#ab2897012e129352ac3f7f491ff1a9676af1eb26b4056cd17dd574c9df8a606b32',1,'arff_token.h']]]
];
