var searchData=
[
  ['integer',['INTEGER',['../arff__value_8h.html#a618674cfaa41c32291efe6766a7c9116a5a063e265d2ac903b6808e9f6e73ec46',1,'arff_value.h']]]
];
