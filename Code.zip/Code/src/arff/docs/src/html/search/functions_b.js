var searchData=
[
  ['set',['set',['../classArffValue.html#a8fe7076e9fc512935fd1603660370317',1,'ArffValue::set(int32 i)'],['../classArffValue.html#abbe5018ee5766a38969d5a8c16e79a4d',1,'ArffValue::set(float f)'],['../classArffValue.html#a300bb023f006ffa72887dc57b6bbbb48',1,'ArffValue::set(const std::string &amp;str, ArffValueEnum e=STRING)']]],
  ['set_5frelation_5fname',['set_relation_name',['../classArffData.html#a70c901c5dd9453d3b5fdb656006a32c9',1,'ArffData']]],
  ['size',['size',['../classArffInstance.html#ae1c7440c5bc04384078215a07152396d',1,'ArffInstance']]],
  ['str2num',['str2num',['../arff__utils_8h.html#ad20499dca67294b192dfb9028e912776',1,'arff_utils.h']]]
];
