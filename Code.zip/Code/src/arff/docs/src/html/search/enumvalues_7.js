var searchData=
[
  ['nominal',['NOMINAL',['../arff__value_8h.html#a618674cfaa41c32291efe6766a7c9116ae2bd7b57b3f0bb02e66e42dbacc5c7fc',1,'arff_value.h']]],
  ['numeric',['NUMERIC',['../arff__value_8h.html#a618674cfaa41c32291efe6766a7c9116a8036f3be5700d4eb67d27fab554d5e0c',1,'arff_value.h']]],
  ['numeric_5ftoken',['NUMERIC_TOKEN',['../arff__token_8h.html#ab2897012e129352ac3f7f491ff1a9676af1eb26b4056cd17dd574c9df8a606b32',1,'arff_token.h']]]
];
