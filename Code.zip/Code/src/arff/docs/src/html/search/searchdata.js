var indexSectionsWithContent =
{
  0: "_abcdefgilmnoprstuvw~",
  1: "a",
  2: "a",
  3: "_acegilmnopstw~",
  4: "bcdmnst",
  5: "ai",
  6: "a",
  7: "abdefimnrsuv",
  8: "o",
  9: "st",
  10: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Macros",
  10: "Pages"
};

