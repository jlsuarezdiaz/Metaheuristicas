var searchData=
[
  ['line',['line',['../classArffScanner.html#af02a598abb0cf19e8cd1e0301da56dfe',1,'ArffScanner']]]
];
