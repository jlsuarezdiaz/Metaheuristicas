/**
 * Uncomment one of the following lines accordong to the desired timer before compiling.
 */

//#define UNIX_TIMER
//#define USUAL_TIMER
#define CPP11_TIMER